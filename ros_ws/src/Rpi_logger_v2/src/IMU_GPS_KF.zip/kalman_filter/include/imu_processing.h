class IMU
{
    public:
        IMU();
    private:
};